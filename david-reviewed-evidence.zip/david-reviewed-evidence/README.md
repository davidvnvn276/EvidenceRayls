# Reviewed DAVID evidence bundle

This archive contains the supplied reproduction harness, a separate independent rerun, an audit and an image plan. Addresses and transaction hashes are local Ganache artifacts.

## Contents

* redemption-lab-v2: original harness, lockfile, original recorded results and manifest.
* independent-run: separately produced results and execution log.
* independent-audit.json: normalized comparison of the two runs.
* david-redemption-v2-reviewed.md: article with small scope clarifications.
* david-v2-audit-and-image-plan.md: Vietnamese audit and design plan.
* verification-manifest.json: SHA-256 of the packaged files.

## Reproduce from this archive

Extract the archive into a directory, then open a terminal there. Git, Node and npm are required. The independent rerun used Node v24.19.0.

```text
git clone https://github.com/raylsnetwork/rayls-sovereign-contracts.git
git -C rayls-sovereign-contracts checkout --detach bdf8f044b9a270e1f97c4c2ac6de9e32ec467de9
cd redemption-lab-v2
npm ci --ignore-scripts --no-audit --no-fund
node run.cjs
```

The git checkout must be clean. See the inner README for environment and test details.

Rerunning replaces files inside redemption-lab-v2 with that run's outputs; the original archive retains the supplied record. Use a separate extracted copy when preserving those recorded hashes matters.

The contracts' tested Teleport routines carry deprecation/decommissioning notices. Endpoint, registry and user governance are mocked, and callbacks are manual on one EVM. This archive establishes contract-level reproduction, not current production behavior, a live relayer, bank redemption, replay protection or a recovery deadline.

Publish an actual accessible artifact URL before claiming that a moderator can download this reproduction package. No public hosting action was performed here.

